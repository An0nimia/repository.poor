#!/usr/bin/python3

class error34(Exception):
	def __init__(self, message):
		Exception.__init__(self, message)